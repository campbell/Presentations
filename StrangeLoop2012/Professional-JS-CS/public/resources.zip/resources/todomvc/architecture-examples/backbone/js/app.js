var app = app || {};
var ENTER_KEY = 13;

$(function() {

	// Kick things off by creating the **App**.
	new app.AppView();

});
