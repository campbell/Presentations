steal
 .plugins("jquery/event/hover",'funcunit/syn')  //load your app
 .plugins('funcunit/qunit')  //load qunit
 .then("hover_test")