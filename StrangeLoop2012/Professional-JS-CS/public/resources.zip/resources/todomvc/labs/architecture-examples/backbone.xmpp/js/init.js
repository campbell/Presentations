// Constants
var ENTER_KEY = 13;

// Setup namespace for the app
window.app = window.app || {};
