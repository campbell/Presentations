Ext.define('Todo.store.Tasks', {
	autoLoad: true,
	model: 'Todo.model.Task',
	extend: 'Ext.data.Store'
});
