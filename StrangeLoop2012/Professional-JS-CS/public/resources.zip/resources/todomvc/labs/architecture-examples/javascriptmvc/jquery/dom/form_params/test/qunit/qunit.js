steal
 .plugins("jquery/dom/form_params")  //load your app
 .plugins('funcunit/qunit','jquery/view/micro')  //load qunit
 .then("form_params_test")