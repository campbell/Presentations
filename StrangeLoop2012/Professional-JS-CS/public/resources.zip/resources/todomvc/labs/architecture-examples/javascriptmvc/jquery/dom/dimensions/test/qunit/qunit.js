steal
 .plugins("jquery/dom/dimensions",'jquery/view/micro')  //load your app
 .plugins('funcunit/qunit')  //load qunit
 .then("dimensions_test")